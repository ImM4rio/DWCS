<?php
    class CocheHidrogeno extends Coche {
        public function consumir(){
            return 'O '.__CLASS__.' consume hidrógeno';
        }
    }
    
?>