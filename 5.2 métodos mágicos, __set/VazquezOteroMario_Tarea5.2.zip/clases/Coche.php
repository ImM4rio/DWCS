<?php
    abstract class Coche{
        abstract public function consumir() ;
    }
    

?>