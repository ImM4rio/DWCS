<?php
    class CocheElectrico extends Coche {
        public function consumir(){
        return 'O ' . __CLASS__ . ' consume electricidade';
        }
    }

?>