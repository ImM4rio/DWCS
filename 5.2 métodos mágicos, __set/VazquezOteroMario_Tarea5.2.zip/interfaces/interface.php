<?php
    interface Comparar{
        public function comparar($value);        
    }

?>