<?php
    echo $_POST['email']." y su nombre es ".$_POST['nombre'];


?>